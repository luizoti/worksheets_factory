"""Dummy stc __init__."""
